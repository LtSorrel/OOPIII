﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch13CardLib
{
   /// <summary>
   ///  Out of range exception for the cards of the deck.
   /// </summary>
    public class CardOutOfRangeException : Exception
    {
        private Cards deckContents;

        public Cards DeckContents
        {
            get
            {
                return deckContents;
            }
        }

        
        public CardOutOfRangeException(Cards sourceDeckContents)
           : base("There Are Only 52 Cards In This Deck!")
        {
            deckContents = sourceDeckContents;
        }
    }
}
