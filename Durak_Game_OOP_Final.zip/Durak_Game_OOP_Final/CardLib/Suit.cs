﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch13CardLib
{
    // The standard suits of cards that will be used in the deck
    public enum Suit
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades,
    }
}
