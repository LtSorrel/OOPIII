﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ch13CardLib;

namespace DurakGameLibrary
{
    /// <summary>
    /// The rules of the Game
    /// </summary>
    
    public class Game
    {
        #region CLASS MEMBERS
   
        static int[] DECK_SIZES = { 20, 36, 52 };        // Deck Size Options
        static int STARTING_HAND_SIZE = 6;               // The initial card count of the player
        #endregion

        #region CONSTRUCTORS

        /// <summary>
        /// Constructor for the Player Game
        /// </summary>
        public Game()
        {
            this.players = new Dictionary<string, Player>();

        }

        // Establishing Player 1 and Player 2 
        public Game(Player p1, Player p2)
        {
            userPlayer = p1;
            AIPlayer = p2;
        }

        #endregion

        #region INSTANCE MEMBERS

        private Dictionary<string, Player> players;
        private Player userPlayer;                      //the User
        private Player AIPlayer;                        // the Computer (which will be controlled by the AI)
        private Talon gameDeck;                         // the game deck, pulled from the Talon.cs 
        private Card theTrumpCard;                      // the trump card

        #endregion

        #region ACCESSORS & MUTATORS
        /// <summary>
        /// Setters and Getters for the properties of the User
        /// </summary>
        
        public Player UserPlayer
        {
            get
            {
                return userPlayer;
            }

            set
            {
               userPlayer = value;
            }
        }

        /// <summary>
        /// Getters and Setters for the AI Computer
        /// </summary>   
        public Player AIComputerPlayer
        {
            get
            {
                return AIPlayer;
            }

            set
            {
                AIPlayer = value;
            }
        }

        /// <summary>
        /// Getters and Setters for the games Trump Card
        /// </summary>
        public Card GameTrumpCard
        {
            get
            {
                return theTrumpCard;
            }

            set
            {
                theTrumpCard = value;
            }
        }

        #endregion

        #region METHODS
        /// <summary>
        ///  The Next Round 
        /// </summary>
        
        public void PlayNextRound()
        {
            

            // Establishing who the first move will be played by
            if (IsUserAttacker())
            {
                // If the player is the User, then select the CardsToPlay function
            }
            else
            {
               // Otherwise the the AI will select the Cards To Play function
            }

        }

        /// <summary>
        /// The round that will establish the players actions. First the user will select cards to play, next the AI will choose their cards, then if the AI  chooses to pass, they will pick up their cards.
        /// </summary>
        public void PlayerRound()
        {
        }

        /// <summary>
        /// Staring the Game.
        /// </summary>
        public void StartGame(int deckSize = 20)
        {
            // Initialize The Players
            try
            {            
               
                // Set the Deck from the Talon and Deal the Cards
                this.gameDeck = new Talon();

                // Next set the deck to the required size of the game.            
                this.gameDeck.SetDeckSize(deckSize);

                // Deal the Cards to the players
                
                // Set the games Trump Card
                theTrumpCard = gameDeck.GetCard();
            }
            // if failed, throw an exception.
            catch (Exception)
            {
                throw;
            }            
        }

        /// <summary>
        /// Ending the Current Game
        /// </summary>
        
        public void EndGame() { }
        
        /// <summary>
        ///  If the Attacker is the User, it will check to see if it is the first round then decide who the attacker is based on the lowest trump card. If it is not the first round, it bases the attacker off of who attacked previously.
        /// </summary>
        /// <returns>true if the attacker is the user, false if it is the AI</returns>
        public bool IsUserAttacker()
        {            
            if (userPlayer.IsAttacker == false && AIPlayer.IsAttacker == false)
            {
                //Checking for the lowest Trump Card to establish the attacker              
                foreach (Card humanCard in userPlayer.PlayerHand)
                {
                    if (humanCard.Suit == theTrumpCard.Suit)
                    {
                        foreach (Card computerCard in AIPlayer.PlayerHand)
                        {
                            if (computerCard.Suit == theTrumpCard.Suit
                                && computerCard.Rank < humanCard.Rank)
                            {
                                UserPlayer.IsAttacker = true;                                
                            }
                        }
                    }
                }
            }
            // Otherwise the User is the Attacker
            else if (AIPlayer.IsAttacker == true)
            {
                UserPlayer.IsAttacker = true;
            }

            // Otherwise the AI is the Attacker              
            else
            {
                UserPlayer.IsAttacker = false;
            }
                          
            // Finally return the Attacker
            return UserPlayer.IsAttacker;
        }
        
        /// <summary>
        /// Dealing the cards based on whetehr it is the first dealing of the cards, or the cards are then dealt based on who the attacker is.
        /// </summary>

        public void Deal()
        {
            //First Check if it is the first deal of the game
            if (UserPlayer.PlayerHand.Count == 0 && AIComputerPlayer.PlayerHand.Count == 0)
            {
                for (int i = 1; i <= STARTING_HAND_SIZE; i++)
                {
                    userPlayer.TakeFromDeck(gameDeck.GetCard());
                    AIPlayer.TakeFromDeck(gameDeck.GetCard());
                }
            }

            else
            {                         
                // If is is not the first deal of the game. Deal to the Attacker first.
                if (UserPlayer.IsAttacker)
                    for (int i = AIComputerPlayer.PlayerHand.Count; i <= STARTING_HAND_SIZE; i++)
                    {
                        AIComputerPlayer.TakeFromDeck(gameDeck.GetCard());
                    }
                else
                    for (int i = UserPlayer.PlayerHand.Count; i <= STARTING_HAND_SIZE; i++)
                    {
                        UserPlayer.TakeFromDeck(gameDeck.GetCard());
                    }
            }
        }  
        #endregion
    }
}
