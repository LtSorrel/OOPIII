﻿/* NameOutOfRangeException.cs - The Exception for the user/player's when it is incorrectly provided
 * 
 * Author : Sarah McCann-Hughes
 * Since :  Feb 2020
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch13CardLibrary
{
    /// <summary>
    /// The out of range Name Exception for an Incorrectly added name on the Users Part.
    /// </summary>
   
    public class NameOutOfRangeException : Exception
    {
        private string name; // Establishing name string
        public string Name
        {
            get
            {
                // Return the name
                return name;
            }
        }

        /// <summary>
        /// default constructor for the Name out of range exception
        /// </summary>
        /// <param name="playerName"></param>
        public NameOutOfRangeException(string playerName)
           : base("Player Name: " + playerName + " is not within the name boundries of 1 - 12 characters. Please Try Again!")
        {
            name = playerName;
        }
    }
}
