﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ch13CardLib;

namespace DurakGameLibrary
{
    class CardsPlayed : Cards
    {
        /// <summary>
        ///  This method is used for the AI player to make decisions, It is activated when the user makes a move and a card is added to the CardsPlayed()
        /// </summary>
        
        Card userLastCardPlayed;        
        
        /// <summary>
        /// These are the getters and setters for the UserLastCardPlayed method.
        /// </summary>
        public Card UserLastCardPlayed
        {
            get
            {
                return userLastCardPlayed;
            }

            set
            {
                userLastCardPlayed = value;
            }
        }
    }
}
