﻿/* Player.cs - The object for the user/player of the game,
 *  includes class and instance variables as well as default and paramaterized constructors.
 * 
 * Author : Sarah McCann- Hughes
 * Since : Feb 2020
 */

using Ch13CardLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DurakGameLibrary
{
    public class Player
    {
        #region CLASS MEMBERS

      // members of the public player class
        public const int MAX_PLAYER_NAME = 12;                          // The Max length that the Players name can be
        public const int MIN_PLAYER_NAME = 1;                           // the Min length that the players name can be
        public const string DEFAULT_NAME = "Player 1";           // The default player name if not entered
        public const int DURAK_GAMES_WON = 0;                         // Number of games the player has won
        public const int DURAK_HANDS_WON = 0;                         // number of hands the player has won
        public const bool IS_DURAK = false;                             // The default DURAK value for the player

        #endregion              

        #region INSTANCE MEMBERS

        private string playerName;          // name of the player
        private Cards playerHand;           // hand of the players cards
        private bool isDurak;               // Is the Player Durak?
        private bool isAttacker;            // Is the player the attacker?
        private int gamesWon;               // Player games won
        private int handsWon;               // player hands won
        #endregion

        #region CONSTRUCTORS

        /// <summary>
        /// Default Constructor for the Player
        /// </summary>
        public Player()
        {
            playerName = DEFAULT_NAME;      // Setting the name default for the player
            playerHand = new Cards();              // Setting up the players hand with new cards
            isDurak = IS_DURAK;                    // Setting the Is_Durak to false initially
            gamesWon = DURAK_GAMES_WON;          //Setting the initial value for the games won
            handsWon = DURAK_HANDS_WON;          // setting the initial value for the hands won
        }

        /// <summary>
        /// This is the Constructor for the player which takes the name as a string 
        /// </summary>
        /// <param name="playerName"></param>

        public Player(string playerName)
        {
            // If the name is within the minimum and maximum length 
            if (playerName.Length <= MAX_PLAYER_NAME && playerName.Length >= MIN_PLAYER_NAME) 
            {
                // Then set the name to the Player name string.
                this.playerName = playerName; 
            }
            // Otherwise
            else
            {
                // Use teh first Characters of the user Input
                this.playerName = playerName.Substring(0, MAX_PLAYER_NAME); 

                // Then throw the out of range exeption
                throw new NameOutOfRangeException(playerName); 
            }

            // If the players name is successful. Set the rest of the values for the game.
            playerHand = new Cards();             
            isDurak = IS_DURAK;                    
            gamesWon = DURAK_GAMES_WON;          
            handsWon = DURAK_HANDS_WON;         
        }

        #endregion

        #region METHODS

        /// <summary>
        /// Playing Card method that plays the cards from the Players Hand.
        /// </summary>
        /// <param name="card"></param>

        public void PlayCard(Card card)
        {
            // Remove a card from the hand of the player to play it.
            playerHand.Remove(card); 
        }

        /// <summary>
        /// Adding Cards to hand
        /// </summary>
        /// <param name="cards"></param>

        public void PickUpCards(Cards cards)
        {
            // For every card that is picked up. Add it to the players hand.
            foreach (Card card in cards) 
            {

                playerHand.Add(card); 
            }
        }

        /// <summary>
        /// Taking a card from the deck and adding it to the Hand
        /// </summary>
        /// <param name="card"></param>

        public void TakeFromDeck(Card card)
        {
            playerHand.Add(card);  
        }

        /// <summary>
        /// Getters and Setters for Setting and Returning the Players Name
        /// </summary>
        public string PlayerName
        {
            get 
            {
                return playerName;
            } 

            set 
            {
                playerName = value; 
            } 
        }

        /// <summary>
        /// Getters And Setters for the Hand of the Player.
        /// </summary>
        
        public Cards PlayerHand
        {
            get 
            { 
                return playerHand;
            } 

            set 
            { 
                playerHand = value; 
            } 
        }

        /// <summary>
        /// Getter & Setter Durak, This determines whether or not the player has lost. If they have, their status will be set to Durak. If not, the Durak status will be set to False
        /// </summary>
        
        public bool IsDurak
        {
            get 
            { 
                return IsDurak; 
            } 

            set 
            { 
                isDurak = value; 
            } 
        }

        /// <summary>
        /// Getters And Setters for the Players Game Win Streak
        /// </summary>

        public int GamesWon
        {
            get 
            { 
                return gamesWon; 
            } 

            set 
            { 
                gamesWon = value; 
            } 
        }

        /// <summary>
        /// Getters and Setters for the Players Hand Win Streak
        /// </summary>

        public int HandsWon
        {
            get 
            {
                return handsWon; 
            } 

            set 
            { 
                handsWon = value; 
            } 
        }

        /// <summary>
        /// Getters and Setters for the attacking player
        /// </summary>

        public bool IsAttacker
        {
            get 
            {
                return isAttacker; 
            }

            set 
            { 
                isAttacker = value; 
            }
        }
        #endregion
    }
}
