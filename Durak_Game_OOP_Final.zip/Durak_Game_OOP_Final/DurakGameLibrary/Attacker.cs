﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ch13CardLib;

namespace DurakGameLibrary
{
    class Attacker : Player
    {
        #region CLASS MEMBERS

        #endregion

        #region CONSTRUCTORS

        #endregion

        #region INSTANCE MEMBERS

        #endregion

        #region METHODS
        //PlayCard(int index);
         //GetCard()
        
        #endregion
    }
}
