﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ch13CardLib;

namespace DurakGameLibrary
{
    class AIPlayer : CardsPlayed
    {
        #region CLASS MEMBERS




        #endregion

        #region CONSTRUCTORS

        /// <summary>
        /// This is the Base constructor for the AI Player Object.
        /// </summary>
        public AIPlayer()
        {

            aiHand = new Cards();   // Create a hand for the AI Player


        }
        #endregion



        #region INSTANCE MEMBERS

        private Cards aiHand;
        private Card playerLastCard;
        private bool attackingPlayer;    // Is the attacker
        private Suit powerSuit;

        #endregion

        #region ACCESSORS & MUTATORS

        /// <summary>
        /// These are the Getters and Setters for the AI Hand
        /// </summary>
        
        public Cards aiPlayerHand
        {
            get
            {
                return aiHand; // Rreturns the AI's Hand of Cards
            }
            set
            {
                aiHand = value; // Sets the AI's Hand of Cards
            }
        }

        /// <summary>
        /// Getters and Setters of the Attacking Player
        /// </summary>
        /// 
        public bool playerAttack
        {
            get
            {
                return attackingPlayer;
            }
            set
            {
                attackingPlayer = value;
            }
        }

        /// <summary>
        /// Getters and Setters for the Players Last Card
        /// </summary>
        
        public Card userLastCard
        {
            get
            {
                return playerLastCard;
            }
            set
            {
                playerLastCard = value;
            }
        }

        public Suit PowerSuit
        {
            get
            {
                return powerSuit;
            }
            set
            {
                powerSuit = value;
            }
        }

        #endregion

        #region METHODS

        /// <summary>
        /// This method removes a cardfrom the AI Players Hand
        /// </summary>
        /// <param name="card"></param>
        
        public void AIPlayingCard(Card card)
        {
            aiHand.Remove(card); // Removes the Played Card from the Hand of the AI Player
        }

        /// <summary>
        /// Drawing Cards to the AI's Hand
        /// </summary>
        /// <param name="card"></param>
        
        public void DrawCards(Card card)
        {
            aiHand.Add(card); // Adds a card to the AI players Hand          
        }

        /// <summary>
        /// This is the basic default logic that in the game the AI player will base it's ability to play by.
        /// </summary>
        public void AILogic()
        {
            // if the player has attacked
            if (playerAttack == true)
            {
                //Go through each card in the AI's hand and assign the ranks to the cards.
                foreach (Card aicard in aiPlayerHand)
                {
                    // if the rank is 2
                    if (aicard.Rank == Rank.Two)
                    {
                        AIPlayingCard(aicard);
                    }

                    // if the rank is 3
                    else if (aicard.Rank == Rank.Three)
                    {
                        AIPlayingCard(aicard);
                    }

                    // if the rank is 4
                    else if (aicard.Rank == Rank.Four)
                    {
                        AIPlayingCard(aicard);
                    }

                    // if the rank is 5
                    else if (aicard.Rank == Rank.Five)
                    {
                        AIPlayingCard(aicard);
                    }

                    // if the rank is 6
                    else if (aicard.Rank == Rank.Six)
                    {
                        AIPlayingCard(aicard);
                    }

                    // if the rank is 7
                    else if (aicard.Rank == Rank.Seven)
                    {
                        AIPlayingCard(aicard);
                    }

                    // if the rank is 8
                    else if (aicard.Rank == Rank.Eight)
                    {
                        AIPlayingCard(aicard);
                    }

                    // if the rank is 9
                    else if (aicard.Rank == Rank.Nine)
                    {
                        AIPlayingCard(aicard);
                    }

                    // if the rank is 10
                    else if (aicard.Rank == Rank.Ten)
                    {
                        AIPlayingCard(aicard);
                    }

                    // if the rank is Jack
                    else if (aicard.Rank == Rank.Jack)
                    {
                        AIPlayingCard(aicard);
                    }

                    // if the rank is Queen
                    else if (aicard.Rank == Rank.Queen)
                    {
                        AIPlayingCard(aicard);
                    }

                    // if the rank is King
                    else if (aicard.Rank == Rank.King)
                    {
                        AIPlayingCard(aicard);
                    }

                    // if the rank is Ace
                    else if (aicard.Rank == Rank.Ace)
                    {
                        AIPlayingCard(aicard);
                    }

                }
            }
            else // Otherwise
            {
                // For each card in the AI's Hand
                foreach (Card aicard in aiPlayerHand)
                {
                    // If the AI's card is greater then or equal to the playerLastCard, then the Player must Draw a card
                    if (playerLastCard >= aicard)
                    {
                        DrawCards(playerLastCard);
                    }


                    // If the playerLastCard is Greter then the AI card OR the Players suit is the same as the AI's suit
                    if (playerLastCard < aicard || playerLastCard.Suit == aicard.Suit)
                    {

                        AIPlayingCard(aicard);

                    }


                    // If the playerLast card is greater then the AI's Card or the AI's card is a PowerSuit
                    if (playerLastCard < aicard || aicard.Suit == powerSuit)
                    {

                        AIPlayingCard(aicard);

                    }

                }

            }

        }
        #endregion
    }
}
