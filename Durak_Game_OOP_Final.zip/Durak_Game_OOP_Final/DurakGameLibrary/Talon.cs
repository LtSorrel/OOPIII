﻿/*  Filename: Talon.cs 
 *  Description - Represents a deck of cards in Durak, inherits from Deck class (Ch13CardLib) Talon
 *  Author  : Sarah McCann-Hughes    
 *  Since : Feb 2020
 *  
 */
using Ch13CardLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DurakGameLibrary
{
    class Talon : Deck
    {
        /// <summary>
        /// Default Constructor
        /// </summary>

        public Talon() 
        { 
        }

        /// <summary>
        /// Takes a value of a supplied and established deck size, and creates it. Each deck size has a different value
        /// </summary>
        /// <param name="deckSize">Deck Size</param>

        public void SetDeckSize(int deckSize)
        {
          
            // For a Deck Size of 20, the Rank Value is 10
            if (deckSize == 20)
            {
                this.CreateDeck(Rank.Ten);
            }

            // For a Deck Size of 36, the Rank Value is 6
            else if (deckSize == 36)
            {
                this.CreateDeck(Rank.Six);
            }

            // For a Deck Size of 52, the Rank Value is 2
            else if (deckSize == 52)
            {
                this.CreateDeck(Rank.Two);
            }

            // Otherwise
            else
            {
                // If one of these deck sizes is not chesen, then throw an Argument Out Of Range Exception
                string errMsg = "The allowable deck sizes are 20, 36, 52";

                throw new ArgumentOutOfRangeException("paramName", errMsg);
            }

            // Otherwise shuffle the deck for playing.
            this.Shuffle();
        }

        /// <summary>
        /// This makes a deck that will start with the lowest card value then build from there to make sure no cards are missed.
        /// </summary>
        /// <param name="minimumRank">Mimumum Value Cards</param>

        public void CreateDeck(Rank minimumRank)
        {
            // Delete any previous deck made to start new
            this.cards.Clear();        

            // establish the lowest ranked cards then build the deck by adding higher valued cards until the deck is full
            for (Suit suitVal = Suit.Clubs; suitVal <= Suit.Spades; suitVal++)
            {
                for (Rank rankVal = minimumRank; rankVal <= Rank.Ace; rankVal++)
                {
                    cards.Add(new Card(suitVal, rankVal));
                }
            }
        }
              
    }
}
