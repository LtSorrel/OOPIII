﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DurakGameLibrary;

namespace Durak_Game_OOP_Final
{
    class Program
    {
        static void Main(string[] args)
        {
            Game theGame = new Game();
            theGame.StartGame();
        }
    }
}
